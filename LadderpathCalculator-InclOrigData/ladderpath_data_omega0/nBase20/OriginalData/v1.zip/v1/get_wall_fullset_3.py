from protools_2_4 import *
from random import randint
import sys

length = int(sys.argv[1])
length2 = int(sys.argv[2])
times = int(sys.argv[3])
step = int(sys.argv[4])

print('lp order size seq')

for i in range(times):
    for leng in range(length,length2+1i,step):
        seq = "".join(aa_order[randint(0,19)] for k in range(leng))
        l,o,s = runstr(seq, show = False)
        print(l,o,s,seq)
