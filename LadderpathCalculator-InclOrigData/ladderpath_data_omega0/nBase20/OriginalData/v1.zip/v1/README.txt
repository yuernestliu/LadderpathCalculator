Base20_v1/ Contained within the index is the comprehensive data pertaining to omega0

  - "5times2000to2500.result" serves as an exemplar, signifying the repetition of computations within the range of 2000 to 2500, undertaken five times.

  - "2000_5000times.result" and "2500_3000times.result" encapsulate the outcomes derived from calculations conducted between fixed endpoints. When combined with the results from "5times2000to2500.result," a comprehensive assessment of Omega0 for the majority of base20 cases is achieved.

  - The codes "get_wall_fullset.py" and "get_wall_fullset_3.py" encompass the computational aspects of data manipulation.
  
  - The file "v1-1-2500-wall_df_temp.xlsx" represents the ultimate desired document.