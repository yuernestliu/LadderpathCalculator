from protools_2_4 import *
from random import randint
import sys

length = int(sys.argv[1])
times = int(sys.argv[2])

print('lp order size seq')

for i in range(times):
    seq = "".join(aa_order[randint(0,19)] for i in range(length))
    l,o,s = runstr(seq, show = False)
    print(l,o,s,seq)
