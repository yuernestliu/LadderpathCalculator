Base4_v1/ Contained within the index is the comprehensive data pertaining to omega0

  - The subdirectories are categorized according to the parameter "Nstep".
    
    - Contained within are the datasets for "Nstep50" and "Nstep100".

    - The script "calculate.py" constitutes the computational codebase.

       - Calculations are performed for omega0 ranging from 1 to 1000, with each point computed a hundred times. The resultant data is summarized in the file "Nstep100.csv".
    
       - For omega0 values spanning from 1001 to 2500, computations are conducted for each point on fifty occasions. The outcomes are compiled in the file "Nstep50.csv".
   
    - The consolidation of data is achieved through the utilization of the script "Calculate_omega0.ipynb".

  - The document "v1_base4.csv" encompasses the summarized data pertaining to the base4 values of omega0.