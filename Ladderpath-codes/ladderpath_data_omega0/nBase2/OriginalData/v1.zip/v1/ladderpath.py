"""
==============================
Version 1.3,
Based on 1st stable release. Main functions to calculate ladderpath.
written by Yu Ernest Liu, 2022.06.10.
Add omega_min() and omega_max() to calculate kappa and eta. 
2023.06.18
==============================
"""
#!/usr/bin/env python
# coding: utf-8


import numpy as np
import pandas as pd
import random
import os

# ============ associated functions ============
def LongestEqSubstr(str1, str2):
    iStartOnly = 0
    substrLenMax = 0
    iStart = 0
    substrLen = 0
    for i, iEle in enumerate(str1):
        if iEle == str2[i]:
            if substrLen == 0:
                iStart = i
            substrLen += 1
        else:
            if substrLen != 0:
                if substrLen > substrLenMax:
                    substrLenMax = substrLen
                    iStartOnly = iStart
                substrLen = 0
    if substrLen > substrLenMax:
        substrLenMax = substrLen
        iStartOnly = iStart
    return substrLenMax, iStartOnly


def LongestSubstr_Diff(str1, str2): # default str1 is longer
    if str1 == str2:
        return len(str1), [0, 0]
    swithed = False
    strLong  = str1
    strShort = str2
    if len(str1) < len(str2):
        swithed = True
        strLong  = str2
        strShort = str1    

    substrLenMax = 0
    idLong  = 0
    idShort = 0
    lenShort = len(strShort)
    lenLong  = len(strLong)
    for i in range(lenLong - 1):
        substrLen, iStart = LongestEqSubstr(strShort[:lenLong-i], strLong[i:i+lenShort])
        if substrLen > substrLenMax:
            substrLenMax = substrLen
            idShort = iStart
            idLong = iStart + i
    for i in range(lenShort - 2):
        substrLen, iStart = LongestEqSubstr(strShort[lenShort-2-i:], strLong[:i+2])
        if substrLen > substrLenMax:
            substrLenMax = substrLen
            idShort = iStart + lenShort - 2 - i
            idLong = iStart
    if swithed:
        return substrLenMax, [idShort, idLong]
    else:
        return substrLenMax, [idLong, idShort]


def LongestSubstr_Self(str0):
    lenstr = len(str0)
    ids = list(range(lenstr))
    maxLen, whereStart = 0, None
    for i in range(1, lenstr - 1):
        str1, str2 = str0[:lenstr-i], str0[i:]
        id1,   id2 =  ids[:lenstr-i],  ids[i:]
        
        eqs = [False] * len(str1)
        eqStartEnd = []
        newEq = False
        for ii, iEle in enumerate(str1):
            if iEle == str2[ii]:
                eqs[ii] = True
                if not newEq:
                    eqStartEnd.append([ii])
                newEq = True
            else:
                if newEq:
                    eqStartEnd[-1].append(ii)
                newEq = False
        if len(eqStartEnd) > 0 and len(eqStartEnd[-1]) == 1:
            eqStartEnd[-1].append(len(str1))

        for istart, iend in eqStartEnd:
            if maxLen < iend - istart:
                thisMaxLen = resolveEqConflict(id1[istart : iend], id2[istart : iend])
                if thisMaxLen > maxLen:
                    maxLen = thisMaxLen
                    whereStart = [istart, istart+i]
    return maxLen, whereStart

def resolveEqConflict(id1group, id2group):
    maxLen = 0
    idsOccupied = [ id2group[0] ]
    broken = False
    for k in range(1, len(id1group)):
        if id1group[k] in idsOccupied:
            maxLen = len(idsOccupied)
            broken = True
            break
        else:
            idsOccupied.append(id2group[k])
    if not broken:
        maxLen = len(id1group)
    return maxLen
    
    
    
def LongestSubstrList_Diff(strList1, strList2):
    maxSubstrLen = 0
    posWanted = None
    ijWanted = None
    for i, istr in enumerate(strList1):
        for j, jstr in enumerate(strList2):
            SubstrLen, pos = LongestSubstr_Diff(istr, jstr)
            if SubstrLen > maxSubstrLen:
                maxSubstrLen = SubstrLen
                posWanted = pos
                ijWanted = [i, j]
    return maxSubstrLen, posWanted, ijWanted


def LongestSubstrList_Self(strList0):
    maxSubstrLen = 0
    posWanted = None
    ijWanted = None
    for i, istr in enumerate(strList0):
        for j, jstr in enumerate(strList0):
            if i == j:
                SubstrLen, pos = LongestSubstr_Self(istr)
                if SubstrLen > maxSubstrLen:
                    maxSubstrLen = SubstrLen
                    posWanted = pos
                    ijWanted = [i, j]
            else:
                SubstrLen, pos = LongestSubstr_Diff(istr, jstr)
                if SubstrLen > maxSubstrLen:
                    maxSubstrLen = SubstrLen
                    posWanted = pos
                    ijWanted = [i, j]
    return maxSubstrLen, posWanted, ijWanted


def switchAB(A, B):
    temp = A
    A = B
    B = temp
    return A, B


def getLevel(links, Level):
    levelComputed = -1
    for ladderonID in links:
        thisLinkLevel = Level[ladderonID]
        if thisLinkLevel is None:
            return None
        else:
            if levelComputed < thisLinkLevel:
                levelComputed = thisLinkLevel
    return levelComputed + 1


# =====================================
class STRMAT(object):
    def __init__(self, strs):
        self.strs = None
        self.Head = []
        self.ID = []
        self.Group = []
        self.maxGroup = len(strs) - 1
        self.targetBook = {}
        self.ladderonBook = {}
        self.ladderonBookLevel0 = {}
        self.ladderonBookDupsExtra = {}
        self.index3 = None
        self.POM = []
        self.omegaMinData = (None, None, None)
        self.omegaMaxData = (None, None, None)
        self.eta = None

        i = 0
        for k, str0 in enumerate(strs):
            self.Head.append([str0])
            self.ID.append( [list(range(i, i+len(str0)))] )
            self.targetBook[str0] = k
            i += len(str0)
            self.Group.append( [[k]*len(str0)] )
            
        self.compData = []  # 初始化compData
        for i in range(len(strs)):
            self.compData.append([])
            for j in range(i+1):
                self.compData[i].append( [None,] )
                
                
    def updateCompData(self, ii, jj):
        if ii == jj:
            substrLen, posWanted, ijWanted = LongestSubstrList_Self(self.Head[ii])
        else:
            substrLen, posWanted, ijWanted = LongestSubstrList_Diff(self.Head[ii], self.Head[jj])
        if substrLen < 2:
            self.compData[ii][jj] = [0,]
        else:
            self.compData[ii][jj] = [substrLen, posWanted, ijWanted]
            
            
    def splitStrs(self, ii, jj, DupInfo):
        substrLen = DupInfo[0]
        if ii == jj:
            if DupInfo[2][0] == DupInfo[2][1]:
                strList, IDList, GroupList = self.Head[ii], self.ID[ii], self.Group[ii]
                iStart1 = DupInfo[1][0]
                iStart2 = DupInfo[1][1]
                if iStart1 > iStart2:
                    iStart1 = DupInfo[1][1]
                    iStart2 = DupInfo[1][0]
                newStrList, newIDList, newGroupList = [], [], []
                for i in range(len(strList)):
                    if i == DupInfo[2][0]:
                        str0splited, IDsplited, GroupSplited, dup, dupInfoComb = self.cut1str2spots(strList[i], IDList[i], GroupList[i], iStart1, iStart2, substrLen)
                        newStrList += str0splited
                        newIDList += IDsplited
                        newGroupList += GroupSplited
                        if dup in self.ladderonBook:
                            self.ladderonBook[dup].append(dupInfoComb[1])
                        else:
                            self.ladderonBook[dup] = dupInfoComb
                    else:
                        newStrList.append(strList[i])
                        newIDList.append(IDList[i])
                        newGroupList.append(GroupList[i])
                self.Head[ii] = newStrList
                self.ID[ii] = newIDList
                self.Group[ii] = newGroupList

            else:
                strList, IDList, GroupList = self.Head[ii], self.ID[ii], self.Group[ii]
                newStrList, newIDList, newGroupList = [], [], []
                iFirst, iSecond = 0, 1
                if DupInfo[2][0] > DupInfo[2][1]:
                    iFirst, iSecond = 1, 0
                for i in range(len(strList)):
                    if i == DupInfo[2][iFirst]:
                        str0splited, IDsplited, GroupSplited, dup, dupInfo = self.cut1str1spot(strList[i], IDList[i], GroupList[i], DupInfo[1][iFirst], substrLen, KeepDup=False)
                        newStrList += str0splited
                        newIDList += IDsplited
                        newGroupList += GroupSplited
                        self.add2ladderonBook(dup, dupInfo, True)
                    elif i == DupInfo[2][iSecond]:
                        str0splited, IDsplited, GroupSplited, _, dupInfo = self.cut1str1spot(strList[i], IDList[i], GroupList[i], DupInfo[1][iSecond], substrLen, KeepDup=True)
                        newStrList += str0splited
                        newIDList += IDsplited
                        newGroupList += GroupSplited
                        self.add2ladderonBook(dup, dupInfo, False)
                    else:
                        newStrList.append(strList[i])
                        newIDList.append(IDList[i])
                        newGroupList.append(GroupList[i])
                self.Head[ii] = newStrList
                self.ID[ii] = newIDList
                self.Group[ii] = newGroupList
        else:  # ii != jj:
            if ii > jj:
                ii, jj = switchAB(ii, jj)
                DupInfo[1][0], DupInfo[1][1] = switchAB(DupInfo[1][0], DupInfo[1][1])
                DupInfo[2][0], DupInfo[2][1] = switchAB(DupInfo[2][0], DupInfo[2][1])
            self.Head[ii], self.ID[ii], self.Group[ii], dup, dupInfo = self.cutFunction(self.Head[ii], self.ID[ii], self.Group[ii], substrLen, DupInfo[1][0], DupInfo[2][0], KeepDup=False)
            self.add2ladderonBook(dup, dupInfo, True)
            self.Head[jj], self.ID[jj], self.Group[jj], _, dupInfo = self.cutFunction(self.Head[jj], self.ID[jj], self.Group[jj], substrLen, DupInfo[1][1], DupInfo[2][1], KeepDup=True)
            self.add2ladderonBook(dup, dupInfo, False)
        return dup
    
    
    def add2ladderonBook(self, dup, dupInfo, firstHalf): # firstHalf表明是否新找到一个ladderon
        if dup in self.ladderonBook:
            if firstHalf:
                self.ladderonBook[dup].append( [dupInfo[1], dupInfo[2]] )
            else:
                self.ladderonBook[dup][-1] += [ dupInfo[1], dupInfo[2] ]
        else:
            self.ladderonBook[dup] = [dupInfo[0], [dupInfo[1], dupInfo[2]] ]
             
    

    def calculatePOM(self):
        if len(self.POM) > 0:
            print('No need to run it again, as it has been calculated.')
        else:
            level0 = []
            for key, val in self.ladderonBookLevel0.items():
                level0.append( (key, val) )
            level0.sort(key=lambda y: (y[1], y[0]))
            pom = [level0]

            if len(self.ladderonBook) == 0: # no ladderon is found
                self.POM = pom
            else:
                Id, Level, Links, Multiplicity = {}, {}, {}, {}
                for ladderon, val in self.ladderonBook.items():
                    ladderonID = val[0]
                    Id[ladderonID] = ladderon  # {5: 'ABDED', 6: 'ABD', 7: 'ED', 8: 'AB'}
                    Level[ladderonID] = None  # {5: None, 6: None, 7: None, 8: None}
                    Links[ladderonID] = []  # {5: [6, 7], 6: [8], 7: [], 8: []}
                    if ladderon in self.ladderonBookDupsExtra:
                        nExtra = self.ladderonBookDupsExtra[ladderon][1]
                    else:
                        nExtra = 0
                    Multiplicity[ladderonID] = len(val)-1 + nExtra # {5: 1, 6: 2, 7: 2, 8: 1}    
                
                temp = []
                for val in self.ladderonBook.values():
                    temp.append(val[0])
                for ladderon, val in self.ladderonBook.items():
                    for upper1, _, upper2, _ in val[1:]:
                        if upper1 in temp and upper1 != val[0]:
                            Links[upper1].append(val[0])
                        if upper2 in temp and upper2 != val[0]:
                            Links[upper2].append(val[0])
                for key, val in Links.items(): # 确定第一层
                    if len(val) == 0:
                        Level[key] = 1
                finished = False
                while not finished:
                    finished = True
                    for ladderonID, val in Level.items():
                        if val is None:
                            finished = False
                            levelComputed = getLevel(Links[ladderonID], Level)
                            if levelComputed is not None:
                                Level[ladderonID] = levelComputed
                for i in range(1, max(Level.values()) + 1):
                    level0 = []
                    for ladderonID, atlevel in Level.items():
                        if atlevel == i:
                            level0.append( (Id[ladderonID], Multiplicity[ladderonID]) )
                    level0.sort(key=lambda y: (y[1], y[0]))
                    pom.append(level0)
                self.POM = pom



    def getOmegaMaxData(self, method_global=True): # return (omegaMax, nBase=None, info)
        if method_global:
            if self.omegaMaxData[2] is None:
                st0 = self.strs[0]
                temp = bin(len(st0))[2:] # 计算长度为 S 的序列的 omega_max
                lpIdx_most_ordered = len(temp) + temp.count('1') - 1
                omegaMax = len(st0) - lpIdx_most_ordered
                info = 'method_global: This omegaMax = omega of a string of A\'s of the same length'
                self.omegaMaxData = (omegaMax, None, info)
            return self.omegaMaxData
        else:
            if self.omegaMaxData[2] is None:
                pass
            return self.omegaMaxData
    def clearOmegaMaxData(self):
        self.omegaMaxData = (None, None, None)
    


    def getOmegaMinData(self, method_global=True, nBase=None, DataFilePath='ladderpath_data_omegaMin/', shuffleN=5): # return (omegaMin, nBase, info)
        if method_global:
            if self.omegaMinData[2] is None:
                if nBase is None:
                    print('! Wrong: nBase has to be given.')
                    return
                omegaMin = None
                DataFilePath_new = DataFilePath + 'nBase' + str(nBase) + '/'
                datafiles = os.listdir(DataFilePath_new)
                _orderlist = []
                for filename in datafiles:
                    temp = filename.split('.')[0][1:]
                    try:
                        _orderlist.append(int(temp))
                    except:
                        pass
                if len(_orderlist) != 0:
                    latestFile = 'v' + str(max(_orderlist)) + '.csv'
                    minData = pd.read_csv(DataFilePath_new + latestFile)
                    omegaMin = float(minData[ minData['size']==len(self.strs[0]) ]['omega'])
                if omegaMin is None:
                    print('omega_min data is not available.')
                else:
                    info = 'method_global: This omegaMin = omega of a random string with nBase. Data source: ' + DataFilePath_new + latestFile
                    self.omegaMinData = (omegaMin, nBase, info)
            return self.omegaMinData
        else:
            if self.omegaMinData[2] is None:
                omegaMin = calOmegaMin_method_local_shuffle(self.strs[0], shuffleN)
                info = 'method_local: This omegaMin = omega of the randomly shuffled original string. ShuffleN = ' + str(shuffleN)
                self.omegaMinData = (omegaMin, None, info)
            return self.omegaMinData
    def clearOmegaMinData(self):
        self.omegaMinData = (None, None, None)
    


    def getEta_global(self, nBase):
        omegaMax = self.getOmegaMaxData()[0]
        if self.omegaMinData[1] is None:
            omegaMin = self.getOmegaMinData(nBase=nBase)[0]
        else:
            if nBase == self.omegaMinData[1]:
                omegaMin = self.omegaMinData[0]
            else:
                print('! Wrong: nBase is not the same with the saved data self.omegaMinData(omegaMin, nBase, info)')
                return
        self.eta = (self.index3[1] - omegaMin) / (omegaMax - omegaMin)
        return self.eta
        


    def dispPOM(self):
        if len(self.POM) == 0:
            print('Partially ordered multiset of the ladderpath has not been computed. Run self.calculatePOM()')
        else:
            print('{ ', end='')
            for level in self.POM[:-1]:
                for ladderon, m in level[:-1]:
                    if m == 1:
                        print(ladderon, ', ', sep='', end='')
                    else:
                        print(ladderon, '(', m, '), ', sep='', end='')
                m = level[-1][1]
                if m == 1:
                    print(level[-1][0], ' // ', sep='', end='')
                else:
                    print(level[-1][0], '(', m, ') // ', sep='', end='')
            level = self.POM[-1]
            for ladderon, m in level[:-1]:
                if m == 1:
                    print(ladderon, ', ', sep='', end='')
                else:
                    print(ladderon, '(', m, '), ', sep='', end='')
            m = level[-1][1]
            if m == 1:
                print(level[-1][0], sep='', end='')
            else:
                print(level[-1][0], '(', m, ')', sep='', end='')
            print('}')

    def disp3index(self):
        print('( Ladderpath-index:', self.index3[0], ',  Order-index:', self.index3[1], ',  Size-index:', self.index3[2], ' )', sep='')
        return self.index3


    def comp3index(self):
        sizeIndex = 0
        for block in self.targetBook.keys():
            sizeIndex += len(block)
        if len(self.ladderonBook) == 0:
            self.index3 = (sizeIndex, 0, sizeIndex)
            return

        for ladderon, val in self.ladderonBook.items(): # {ladderon: [Group, [UpperGroup1, iStart1, UpperGroup2, iStart2], ... ]
            if val[1][1] is None:
                sizeIndex += len(ladderon)
        if len(self.ladderonBookDupsExtra) > 0:
            for dup, val in self.ladderonBookDupsExtra.items():
                sizeIndex += len(dup) * val[1]

        orderIndex = 0
        for ladderon, val in self.ladderonBook.items():
            orderIndex += (len(ladderon)-1) * (len(val)-1)
        if len(self.ladderonBookDupsExtra) > 0:
            for dup, val in self.ladderonBookDupsExtra.items():
                orderIndex += (len(dup)-1) * val[1]

        ladderpathIndex = sizeIndex - orderIndex
        self.index3 = (ladderpathIndex, orderIndex, sizeIndex)


    def cutFunction(self, strList, IDlist, Grouplist, substrLen, iStart, ipos, KeepDup):
        newStrList, newIDList, newGroupList = [], [], []
        for i in range(len(strList)):
            if i == ipos:
                str0splited, IDsplited, GroupSplited, dup, dupInfo = self.cut1str1spot(strList[i], IDlist[i], Grouplist[i], iStart, substrLen, KeepDup)
                newStrList += str0splited
                newIDList += IDsplited
                newGroupList += GroupSplited
            else:
                newStrList.append(strList[i])
                newIDList.append(IDlist[i])
                newGroupList.append(Grouplist[i])
        return newStrList, newIDList, newGroupList, dup, dupInfo


    def cut1str1spot(self, str0, ID0, Group0, iStart, substrLen, KeepDup):
        str0splited, IDsplited, GroupSplited = [], [], []
        if iStart > 1:
            str0splited.append(str0[:iStart])
            IDsplited.append(ID0[:iStart])
            GroupSplited.append(Group0[:iStart])
        dup = str0[iStart : iStart+substrLen]
        if dup in self.ladderonBook:
            dupInfo = [self.ladderonBook[dup][0], Group0[iStart], ID0[iStart]]
        else:
            self.maxGroup += 1
            dupInfo = [self.maxGroup, Group0[iStart], ID0[iStart]]
        if KeepDup:
            str0splited.append(dup)
            IDsplited.append(ID0[iStart : iStart+substrLen])
            GroupSplited.append( [ dupInfo[0] ]*substrLen )
                
        if iStart + substrLen < len(str0) - 1: # 如果是单个字符，则不记录
            str0splited.append(str0[iStart + substrLen :])
            IDsplited.append(ID0[iStart + substrLen :])
            GroupSplited.append(Group0[iStart + substrLen :])
        return str0splited, IDsplited, GroupSplited, dup, dupInfo


    def cut1str2spots(self, str0, ID0, Group0, iStart1, iStart2, substrLen):
        str0splited, IDsplited, GroupSplited = [], [], []
        if iStart1 > 1:
            str0splited.append(str0[:iStart1])
            IDsplited.append(ID0[:iStart1])
            GroupSplited.append(Group0[:iStart1])
        dup = str0[iStart1 : iStart1+substrLen]
        if dup in self.ladderonBook:
            dupInfoComb = [self.ladderonBook[dup][0], [Group0[iStart1], ID0[iStart1]] ]
        else:
            self.maxGroup += 1
            dupInfoComb = [self.maxGroup, [Group0[iStart1], ID0[iStart1]] ]
        
        if iStart1 + substrLen < iStart2 - 1:
            str0splited.append(str0[iStart1 + substrLen : iStart2])
            IDsplited.append(ID0[iStart1 + substrLen : iStart2])
            GroupSplited.append(Group0[iStart1 + substrLen : iStart2])

        str0splited.append(dup)
        IDsplited.append(ID0[iStart2 : iStart2+substrLen])
        GroupSplited.append( [ dupInfoComb[0] ]*substrLen )
        dupInfoComb[1] += [Group0[iStart2], ID0[iStart2]]

        if iStart2 + substrLen < len(str0) - 1: # 如果是单个字符，则不记录
            str0splited.append(str0[iStart2 + substrLen :])
            IDsplited.append(ID0[iStart2 + substrLen :])
            GroupSplited.append(Group0[iStart2 + substrLen :])
        return str0splited, IDsplited, GroupSplited, dup, dupInfoComb

    

# =====================================
def ladderpath(strsInput, CalPOM=True):
# strsInput = ['ABCAB', 'BACAX', 'BACAX'] 或 strsInput = {'ABCAB': 2, 'BACAX': 1, 'BACAX': 1}
    hasDup = False
    if type(strsInput) == list:
        countStrs = {}
        for str0 in strsInput:
            if str0 in countStrs:
                hasDup = True
                countStrs[str0] += 1
            else:
                countStrs[str0] = 1
        if hasDup:
            strs = list(countStrs.keys())
        else:
            strs = strsInput
    elif type(strsInput) == dict:
        countStrs = strsInput
        strs = list(strsInput.keys())
        if max(strsInput.values()) > 1:
            hasDup = True
    else:
        print('Error: The type of input for strs is incorrect; it must be either a list or a dict.')
        return

    strMat = STRMAT(strs)
    if hasDup:
        for block, ndup in countStrs.items():
            if ndup > 1:
                Group = strMat.targetBook[block]
                strMat.ladderonBook[block] = [Group, [Group, None, Group, None]]
                strMat.ladderonBookDupsExtra[block] = [Group, ndup-2]
        strMat.strs = strs
    else:
        strMat.strs = strs

    lenStrs = len(strs)
    for i in range(lenStrs):
        for j in range(i+1):
            strMat.updateCompData(i, j)

    maxLen = 1
    while maxLen > 0:
        maxLen = 0
        imax, jmax = 0, 0
        for i in range(lenStrs):
            for j in range(i+1):
                if maxLen < strMat.compData[i][j][0]:
                    maxLen = strMat.compData[i][j][0]
                    imax, jmax = i, j
        if maxLen > 0:
            thisDupInfo = strMat.compData[imax][jmax]
            strMat.splitStrs(imax, jmax, thisDupInfo)

            if imax > jmax:
                temp = imax
                imax = jmax
                jmax = temp
            for k in range(imax):
                strMat.updateCompData(imax, k)
            for k in range(imax, lenStrs):
                strMat.updateCompData(k, imax) 

            for k in range(jmax):
                if k != imax:
                    strMat.updateCompData(jmax, k)
            for k in range(jmax, lenStrs):
                strMat.updateCompData(k, jmax) 
    
    # ------ Computing information for Level 0 ------
    countLetters0 = {} # in the original blocks0, the number of each letter
    for target0 in strMat.targetBook.keys():
        if target0 in strMat.ladderonBookDupsExtra:
            nExtra = strMat.ladderonBookDupsExtra[target0][1] + 1
        else:
            nExtra = 0
        for x in target0:
            if x in countLetters0:
                countLetters0[x] += 1 + nExtra
            else:
                countLetters0[x] = 1 + nExtra

    Multiplicity = {}
    countLetters = {} # among all the ladderons, the number of each letter
    for ladderon, val in strMat.ladderonBook.items():
        if ladderon in strMat.ladderonBookDupsExtra:
            nExtra = strMat.ladderonBookDupsExtra[ladderon][1]
        else:
            nExtra = 0

        ladderonId = val[0]
        Multiplicity[ladderonId] = len(val) - 1 + nExtra  # {5: 1, 6: 2, 7: 2, 8: 1}  
        for x in ladderon:
            if x in countLetters:
                countLetters[x] += Multiplicity[ladderonId]
            else:
                countLetters[x] = Multiplicity[ladderonId]

    for key, val in countLetters0.items():
        if key in countLetters:
            strMat.ladderonBookLevel0[key] = val - countLetters[key]
        else:
            strMat.ladderonBookLevel0[key] = val

    strMat.comp3index()
    if CalPOM:
        strMat.calculatePOM()

    return strMat



def calOmegaMin_method_local_shuffle(st0, shuffleN):
    orderIdxArray = np.array([-1] * shuffleN)
    st0_list = list(st0)
    for i in range(shuffleN):
        random.shuffle(st0_list)
        st0_shuffled = ''.join(st0_list)
        lp0 = ladderpath([st0_shuffled], CalPOM=False)
        orderIdxArray[i] = lp0.index3[1]
    return np.mean(orderIdxArray)