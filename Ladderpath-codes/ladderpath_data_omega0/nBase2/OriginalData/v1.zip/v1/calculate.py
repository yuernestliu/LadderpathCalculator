import numpy as np
import random
import ladderpath as lp
import pandas as pd
from multiprocessing.pool import Pool

def CountOmega(t):
    nBase = 10
    S_max = 5
    N_repeat = 30

    letterList = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0']
    omegaMat = {}
    for S in range(S_max*t+1, S_max*(t+1)+1):
        omegaList = []
        for i in range(N_repeat):
            str0 = [ ''.join( letterList[random.randint(0, nBase-1)] for _ in range(S) ) ]
            lp0 = lp.ladderpath(str0)
            omegaList.append( lp0.index3[1] )
            if (i + 1) % 50 == 0:
                print(f"(t={t}) finish {(i + 1)}")
        omegaMat[S] = omegaList
    omegaMat = pd.DataFrame(omegaMat)
    fileName = './test_result/'+'notebook'+'nBase' + str(nBase) + '-Smax' + str(S_max)+ '-t' +str(t) + '-Nrep' + str(N_repeat) + '.csv'
    omegaMat.to_csv(fileName)
    
if __name__ == '__main__': 
    pool = Pool(processes=30)
    t = list(range(20, 50))
    result = pool.map(CountOmega,t)
    pool.close()
    pool.join()
