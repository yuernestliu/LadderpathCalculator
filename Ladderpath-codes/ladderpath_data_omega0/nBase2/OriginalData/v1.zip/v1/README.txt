Base2_v1/ Contained within the index is the comprehensive data pertaining to omega0

  - Subdirectory: original data
    
    - Contained within are the initial data sets post-computer processing

  - Subdirectory: Processed data
    
    - The data that has been processed through the file "Calculate_omega0.ipynb".
    
    - The CSV file serves the purpose of amalgamating data of the same category from the original dataset.

    - The TXT file undertakes the transformation of the aforementioned CSV document into the desired format.
    
  - The script "Calculate_omega0.ipynb" constitutes the data processing code, encompassing explanatory elements within its specific treatment procedures.

  - The file "data.txt" amalgamates the TXT documents from the processed data, accompanied by detailed descriptions of the applied processing methodologies.

  - The codes "calculate.py" and "ladderpath.py" encompass the computational aspects of data manipulation.
  
  - The file "omega0.csv" represents the ultimate desired document.
